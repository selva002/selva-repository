<?php
require_once 'db.php';

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css" type="text/css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div><h3 class="well col-sm-offset-4 col-sm-4 bg-secondary text-white"style="text-align:center;">Return Books</h3></div>
</div>
<div class="container">

<div class="table-responsive">
<table class="table">
<form class="form-group" action="ret.sub.php" method="POST">
<tr>
<td><input type="text" class="form-control" placeholder="User ID" name="UserID" value=""></td>
<td><input type="text" class="form-control" placeholder="Book ID" name="BookID" value=""></td>
<td><input type="date" name = "date[]" hidden value="<?php echo $Return; ?>"></td>
<td><button type="submit" name="submit" class="btn btn-info form-control">Submit</button></td>
</tr>
</form>
</table>
</div>
</div>

</body>
</html>
