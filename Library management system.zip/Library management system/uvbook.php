<?php
require_once 'db.php';
$query = "select * from management";
$result = mysqli_query($conn,$query);

?>


<!DOCTYPE html>
<html>
<head>
<title> home page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="cs/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  

  
  
</head>
<body>
<div class="container">
<div>

<h3 class="well col-sm-offset-4 col-sm-4 bg-secondary text-white" style="text-align:center"> Issue & Return Books </h3>
</div>
</div>

<div class="container">


<div class="table-responsive" >
<table class="table">

<tr>

<td>User ID </td>
<td>Book ID</td>
<td>Issue Date </td>
<td>Return Date </td>
</tr>


 <form action="#" method="POST">
 
 <?php
 
 while ($row = mysqli_fetch_assoc($result))
 { 

	 $UserID = $row['User_ID'];
	 $BookID = $row['Book_ID'];
	 $IssueDate = $row['Issue_Date'];
	 $ReturnDate = $row['Return_Date'];
	 
 ?>
 <div>
 <tr>
 
 <td><?php echo $UserID ?> </td>
<td><?php echo $BookID ?></td>
<td><?php echo $IssueDate?></td>
<td><?php echo $ReturnDate?></td>	
 </tr>
 </div>
 <?php
 }
 ?>
 </form>
 
  
 </table>
 </div>
 
 </div>
 </div>
 </div>
 </body>
</html>