<?php

$conn = mysqli_connect("localhost","root","","lms");

/*if(!$conn){
	
	die ('error connection database');
}
else{
	echo 'you have created case';
}*/
	
	


?>