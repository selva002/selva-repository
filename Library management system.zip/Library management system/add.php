<?php
include_once 'book.php';
require_once 'db.php';

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css" type="text/css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div>
<h3> Add Books</h3>
</div>

<div class="table-responsive">
<table class="table">
<form class="form-group" action="add.ins.php" method="POST" >
<tr>
<td><input type="text" class="form-control" placeholder="Book ID" name="BookID"></td>
<td><input type="text" class="form-control" placeholder="Book Name" name="BookName"></td>
<td><input type="text" class="form-control" placeholder="Author Name" name="AuthorName"></td>
<td><input type="text" class="form-control" placeholder="Edition" name="Edition"></td>
<td><button type="submit" name="Add" class="btn btn-info form-control">add</button></td>
</tr>
</form>
</table>

</body>
</html>

