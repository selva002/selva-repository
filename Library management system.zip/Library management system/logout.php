
<?php
/*session_start();

if (isset($_SESSION['id'])){
	
session_destroy();

echo 'You have been logged out. <a href="user.php">Go back</a>';

}*/

session_start();
session_destroy();
unset($_SESSION['id']);
$_SESSION['message'] = "you are logged out";

header("location:user.php");

?>