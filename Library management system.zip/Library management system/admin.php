<?php

require_once 'db.php';

?>

<!DOCTYPE html>
<html>
<head>
<title> Admin page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body style="background-color:#333;">


<div class="container">

<div class="col-md-10">
<h1 class="col-md-offset-4 text-danger">Library Management System</h1></div>
</div>



&nbsp &nbsp


<div class="container" id="form">
<div class="row">
<div class="col-md-offset-4 col-md-4">

<h2 class="text-info" style="text-align:center;"> Admin login </h2>
<form action="admin.login.php" method="POST">
<input type="text" name="AdminID" placeholder="UserName" id= "USerName" size="25" class="form-control">
<input type="password" name="Password" placeholder="Password" id= "Password" size="25" class="form-control"></br>

<button type="submit" name="admin" class="btn btn-danger form-control">Login</button>