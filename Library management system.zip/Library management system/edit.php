<?php

include_once 'book.php';


require_once 'db.php';

$BookID = $_GET['GetID'];

$query = "select * from Books_library where Book_ID='".$BookID."'";

$result = mysqli_query($conn,$query);

while($row=mysqli_fetch_assoc($result))
{
	 $BookID = $row['Book_ID'];
	 $BookName = $row['Book_Name'];
	 $AuthorName = $row['Author_Name'];
	 $Edition = $row['edition'];
	
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css" type="text/css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div>
<h3> update books</h3>
</div>

<div class="table-responsive">
<table class="table">
<form action="update.php" method="POST">
<tr>
<td><input type="text" class="form-control" placeholder="Book ID" name="BookID" value="<?php echo $BookID ?>" readonly></td>
<td><input type="text" class="form-control" placeholder="Book Name" name="BookName" value="<?php echo $BookName ?>"></td>
<td><input type="text" class="form-control" placeholder="Author Name" name="AuthorName" value="<?php echo $AuthorName ?>"></td>
<td><input type="text" class="form-control" placeholder="Edition" name="Edition" value="<?php echo $Edition ?>"></td>
<td><button type="submit" name="update" class="btn btn-info form-control">update</button></td>
 </tr>
 </form>
 </table>

</body>
</html>


