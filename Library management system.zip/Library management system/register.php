


<?php
require_once 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
<title> register page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="cs/sty.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  
    
  
  
</head>

<body style="background-image:url(cs/library1.jpg);background-size:cover">

<div class="container" id="reg">


<div class="col-sm-offset-4 col-sm-4">
<h2 class="text-info"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Register</h2>
<form class="form-group" action="insert.php" method="POST" >
<input type="text" name="UserName" placeholder="UserName" class="form-control">
<input type="password" name="Password" placeholder="password" class="form-control">
<input type="textarea" name="Address" placeholder="Address" class="form-control">
<button type="submit" name="Register" class="btn btn-info form-control">Register</button>
</form>
</div>

</div>

</body>
</html>


