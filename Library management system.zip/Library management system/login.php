<?php
session_start();
if(isset($_SESSION["user"])){
    header("location:index.php");
    exit();
}

?>


<?php
require_once 'db.php';

if(isset($_POST['login']))
 {
	if(empty($_POST['UserName']) || empty($_POST['Password']))
		
		{
			echo "<script>alert('please enter username and password')</script>";
			
			echo "<script>location.href='user.php'</script>";
		}
		/*else
		{ // if checkd inside input charcter and valid
		   $sql = "SELCET * FROM register WHERE User_ID='$UserID'";
		   $result = mysqli_query($conn,$sql);
		   $resultcheck = mysqli_num_rows($result);
		   if($resultcheck < 1)
		   {
			   echo "<script>alert('wrong user name')</script>";
			
			echo "<script>location.href='user.php'</script>";
           } 
		   
		}*/
		else{
		

               $UserName = $_POST['UserName'];
               $Password = $_POST['Password'];

                $query = "select * from register WHERE User_Name = '$UserName' AND Password = '$Password'";
                $result = mysqli_query($conn,$query);
                $resultcheck = mysqli_num_rows($result);
                $row = mysqli_fetch_assoc($result);

               if($resultcheck)
   {
	session_start();
	$_SESSION['id']= $row['User_ID'];
	$id =$_SESSION['id'];
	
	header("location:userbook.php");
}
else
		{
			echo "<script>alert('please check password or username')</script>";
			
			echo "<script>location.href='user.php'</script>";
		}

 }}

else
{
	header("location:index.php");
}


?>

