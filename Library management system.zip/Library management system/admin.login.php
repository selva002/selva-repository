<?php

require_once 'db.php';

if(isset($_POST['admin']))
 {
	if(empty($_POST['AdminID']) || empty($_POST['Password']))
		
		{
			echo "please fill in the blanks";
		}
		else
		{

$UserName = $_POST['AdminID'];
$Password = $_POST['Password'];

$query = "select * from admin WHERE admin_id = '$UserName' AND admin_pass = '$Password'";
$result = mysqli_query($conn,$query);
$resultcheck = mysqli_num_rows($result);

if($resultcheck)
 {
	header("location:home.php");
 }
else
		{
			echo 'please check password or username';
		}

}
}
else
{
	header("location:admin.php");
}


?>
