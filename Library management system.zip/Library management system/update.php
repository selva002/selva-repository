<?php

require_once 'db.php';


if(isset($_POST['update']))
{
      $BookID = $_POST['BookID'];
	 $BookName = $_POST['BookName'];
	 $AuthorName = $_POST['AuthorName'];
	 $Edition = $_POST['Edition'];
	 
	 $query = "update books_library set Book_Name ='$BookName',Author_Name='$AuthorName',edition='$Edition' WHERE Book_ID='$BookID'";

      $result = mysqli_query($conn,$query);
	  
	  if($result)
	  {
		  header("location:book.php");
	  }
	  else
	  {
		  echo 'please check the query';
	  }

}
else
{
	header("location:update.php");
}
?>