<?php

require_once 'db.php';

if(isset($_POST['Add']))
{
	if(empty($_POST['BookID']) || empty($_POST['BookName']) || empty($_POST['AuthorName']) || empty($_POST['Edition']))
	{
		echo 'please fill the blanks';
	}
	else
	{
		$BookID = $_POST['BookID'];
	  $BookName = $_POST['BookName'];
	  $AuthorName = $_POST['AuthorName'];
	  $Edition = $_POST['Edition'];
	  
	  $query = "insert into books_library(Book_ID,Book_Name,Author_Name,edition) values('$BookID','$BookName','$AuthorName','$Edition')";
	  
	  $result = mysqli_query($conn,$query);
	  
	  if($result)
	  {
		  header("location:book.php");
		 
	  }
	  else
	  {
		  echo 'please check query';
	  }
	}
}
else
{
  header("location:add.php");	
}

?>