<?php

require_once 'db.php';

if(isset($_GET['del']))
{
	$BookID = $_GET['del'];
	$query = "delete from books_library where Book_ID ='".$BookID."'";
	$result = mysqli_query($conn,$query);

if($result)
	
	{
		header("location:book.php");
	}
else
{
	echo 'check the query';
	
}


}





?>

