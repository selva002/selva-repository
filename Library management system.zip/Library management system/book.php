<?php
require_once 'db.php';
$query = "select * from books_library";
$result = mysqli_query($conn,$query);

?>



<!DOCTYPE html>
<html>
<head>
<title> home page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  
</head>
<body>
<div class="container">

<h3 class="well"style="text-align:center;">available books </h3>

<div class="table-responsive">
<table class="table">
<div style="text-align:right";><button type="btn" class="btn btn-defult"><a href="add.php">Add Books</a></button></div>
<tr>
<td>Book ID </td>
<td>Book Name</td>
<td>Author Name </td>
<td>Edition </td>
<td>Edit </td>
<td>Delete </td>	
 </tr>
 
 
 <?php
 
 while ( $row = mysqli_fetch_assoc($result))
 {
	$BookID = $row['Book_ID'];
	 $BookName = $row['Book_Name'];
	 $AuthorName = $row['Author_Name'];
	 $Edition = $row['edition'];
	 
	
 
 
 ?>
 
 <tr>
 <td><?php echo $BookID ?> </td>
<td><?php echo $BookName ?></td>
<td><?php echo $AuthorName ?></td>
<td><?php echo $Edition ?> </td>
<td><a href="edit.php?GetID=<?php echo $BookID ?>"> Edit</a></td>
<td><a href="Delete.php?del=<?php echo $BookID ?>"> Delete</a></td>	


 </tr>
 <?php
 }
 ?>
 </table>
 </div>
 </div>
 
 
</body>
</html>